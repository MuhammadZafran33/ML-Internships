"""
Builds the neofetch-style profile card (dark_mode.svg / light_mode.svg).

Run it by hand:   python update_readme.py
or let .github/workflows/update.yml run it every day to refresh the GitHub stats.

Everything you may want to edit lives in PROFILE below.
"""
import calendar
import json
import os
import time
from datetime import date
from xml.sax.saxutils import escape

import requests

# ----------------------------------------------------------------------------
# 1) EDIT ME
# ----------------------------------------------------------------------------
PROFILE = {
    "username": "MuhammadZafran33",
    "user_at_host": "muhammad@zafran",
    "birthdate": None,  # e.g. "2003-05-17" -> shows an "Uptime" line. None hides it.
    "info": [  # (key, value)  -- a None key means "blank line"
        ("OS", "Windows 11, Google Colab, Kaggle"),
        ("Host", "IM|Sciences, Peshawar"),
        ("Kernel", "BS Artificial Intelligence"),
        ("Internships", "Excelerate, Arch Technologies"),
        ("IDE", "VS Code, Jupyter, Google Colab"),
        None,
        ("Languages.Programming", "Python, SQL"),
        ("Languages.Computer", "JSON, CSV, HTML, Markdown"),
        ("Languages.Real", "English, Urdu, Pashto"),
        None,
        ("Skills.ML", "Deep Learning, LLMs, Agentic AI"),
        ("Skills.Tools", "scikit-learn, Streamlit, Power BI"),
        ("Hobbies.Software", "Data Viz, Kaggle, Open Source"),
        ("Community", "PMGYM, Qalb Welfare Foundation"),
    ],
    "contact": [
        ("Email.Personal", "zafrankhaan33@gmail.com"),
        ("LinkedIn", "muhammad-zafran-93344a352"),
        ("Fiverr", "muh_zafran"),
    ],
}

# ----------------------------------------------------------------------------
# 2) Layout constants (monospace: char width = 0.6 * font size)
# ----------------------------------------------------------------------------
ART_FS, ART_LH = 11, 13.5
INFO_FS, INFO_LH = 14.5, 20.5
ART_CW, INFO_CW = ART_FS * 0.6, INFO_FS * 0.6
INFO_COLS = 60
PAD = 20
GAP = 26

THEMES = {
    "dark_mode.svg": dict(bg="#161b22", art="#c9d1d9", text="#c9d1d9", key="#ffa657",
                          value="#a5d6ff", cc="#616e7f", add="#3fb950", dele="#f85149"),
    "light_mode.svg": dict(bg="#f6f8fa", art="#24292f", text="#24292f", key="#953800",
                           value="#0a3069", cc="#c2cfde", add="#116329", dele="#cf222e"),
}

HERE = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.join(HERE, "stats_cache.json")


# ----------------------------------------------------------------------------
# 3) GitHub stats (public REST API, no extra libraries)
# ----------------------------------------------------------------------------
def _get(url, session, params=None):
    return session.get(url, params=params, timeout=30)


def fetch_stats(username, token=None):
    s = requests.Session()
    s.headers["Accept"] = "application/vnd.github+json"
    if token:
        s.headers["Authorization"] = f"Bearer {token}"

    user = _get(f"https://api.github.com/users/{username}", s)
    user.raise_for_status()
    user = user.json()

    repos, page = [], 1
    while True:
        r = _get(f"https://api.github.com/users/{username}/repos", s,
                 {"per_page": 100, "page": page, "type": "owner"})
        r.raise_for_status()
        batch = r.json()
        repos += batch
        if len(batch) < 100:
            break
        page += 1

    own = [r for r in repos if not r["fork"]]
    stars = sum(r["stargazers_count"] for r in own)
    commits = added = deleted = 0
    incomplete = False

    for repo in own:
        url = f"https://api.github.com/repos/{username}/{repo['name']}/stats/contributors"
        for _ in range(6):  # GitHub answers 202 while it computes the stats
            r = _get(url, s)
            if r.status_code != 202:
                break
            time.sleep(3)
        if r.status_code == 204:      # empty repo: nothing to count
            continue
        if r.status_code != 200:      # 202 never finished, 403 rate limit, ...
            incomplete = True
            continue
        for c in r.json():
            if c["author"] and c["author"]["login"].lower() == username.lower():
                commits += c["total"]
                added += sum(w["a"] for w in c["weeks"])
                deleted += sum(w["d"] for w in c["weeks"])

    return {
        "repos": user["public_repos"], "stars": stars,
        "followers": user["followers"],
        # None = could not be counted completely this run (keep the last good value)
        "commits": None if incomplete else commits,
        "added": None if incomplete else added,
        "deleted": None if incomplete else deleted,
    }


def load_stats():
    old = {}
    if os.path.exists(CACHE):
        with open(CACHE) as f:
            old = json.load(f)
    token = os.environ.get("ACCESS_TOKEN") or os.environ.get("GITHUB_TOKEN")
    try:
        new = fetch_stats(PROFILE["username"], token)
    except Exception as exc:  # rate limit, offline, ...
        print(f"[warn] could not refresh stats ({exc}); using cached values")
        return old or None
    merged = {k: (v if v is not None else old.get(k)) for k, v in new.items()}
    if any(v is None for v in new.values()):
        print("[warn] commit / line counts incomplete this run (GitHub rate limit?); "
              "kept previous values. Run with a token to get them.")
    with open(CACHE, "w") as f:
        json.dump(merged, f)
    return merged


# ----------------------------------------------------------------------------
# 4) Line builders: each returns (plain_text_length, svg_markup)
# ----------------------------------------------------------------------------
def span(cls, text):
    return f'<tspan class="{cls}">{escape(text)}</tspan>'


def kv(key, value, width, bullet=". "):
    head = f"{bullet}{key}:"
    dots = max(3, width - len(head) - len(value) - 2)
    markup = (span("cc", bullet) + span("key", key) + span("text", ":")
              + span("cc", " " + "." * dots + " ") + span("value", value))
    return len(head) + 2 + dots + len(value), markup


def rule(title, width):
    head = f"- {title} "
    return width, span("text", head) + span("cc", "-" * (width - len(head)))


def header(user_at_host, width):
    head = f"{user_at_host} "
    return width, span("key", head) + span("cc", "-" * (width - len(head)))


def uptime_value(birthdate):
    b = date.fromisoformat(birthdate)
    t = date.today()
    months_total = (t.year - b.year) * 12 + (t.month - b.month) - (t.day < b.day)
    years, months = divmod(months_total, 12)
    y = b.year + (b.month - 1 + months_total) // 12
    m = (b.month - 1 + months_total) % 12 + 1
    last = date(y, m, min(b.day, calendar.monthrange(y, m)[1]))
    return f"{years} years, {months} months, {(t - last).days} days"


def fmt(n):
    return "--" if n is None else f"{n:,}"


def build_info_lines(stats):
    lines = [header(PROFILE["user_at_host"], INFO_COLS)]
    items = list(PROFILE["info"])
    if PROFILE["birthdate"]:
        items.insert(0, ("Uptime", uptime_value(PROFILE["birthdate"])))
    for item in items:
        lines.append(None if item is None else kv(*item, INFO_COLS))

    lines.append(None)
    lines.append(rule("Contact", INFO_COLS))
    for k, v in PROFILE["contact"]:
        lines.append(kv(k, v, INFO_COLS))

    lines.append(None)
    lines.append(rule("GitHub Stats", INFO_COLS))
    g = (lambda k: stats.get(k)) if stats else (lambda k: None)

    def pair(lk, lv, rk, rv):
        n1, m1 = kv(lk, lv, 29)
        n2, m2 = kv(rk, rv, 28)
        return n1 + 3 + n2, m1 + span("text", " | ") + m2

    lines.append(pair("Repos", fmt(g("repos")), "Stars", fmt(g("stars"))))
    lines.append(pair("Commits", fmt(g("commits")), "Followers", fmt(g("followers"))))

    head = ". Lines of Code:"
    if stats and g('added') is not None:
        a, d = f"{g('added'):,}++", f"{g('deleted'):,}--"
        total = f"{g('added') + g('deleted'):,}"
        tail_len = len(total) + len(" ( ") + len(a) + 2 + len(d) + len(" )")
        dots = max(3, INFO_COLS - len(head) - tail_len - 2)
        markup = (span("cc", ". ") + span("key", "Lines of Code") + span("text", ":")
                  + span("cc", " " + "." * dots + " ") + span("value", total + " ( ")
                  + span("add", a) + span("value", ", ") + span("del", d) + span("value", " )"))
        lines.append((len(head) + 2 + dots + tail_len, markup))
    else:
        lines.append(kv("Lines of Code", "--", INFO_COLS))
    return lines


# ----------------------------------------------------------------------------
# 5) Assemble the SVG
# ----------------------------------------------------------------------------
def build_svg(theme, art_lines, info_lines):
    art_cols = max(len(l) for l in art_lines)
    art_w = art_cols * ART_CW
    info_w = INFO_COLS * INFO_CW
    art_h = len(art_lines) * ART_LH
    info_h = len(info_lines) * INFO_LH
    width = round(PAD + art_w + GAP + info_w + PAD)
    height = round(max(art_h, info_h) + 2 * PAD + 10)
    info_x = PAD + art_w + GAP

    out = [
        f'<?xml version="1.0" encoding="UTF-8"?>',
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}px" height="{height}px" '
        f'viewBox="0 0 {width} {height}">',
        '<title>Muhammad Zafran - GitHub profile</title>',
        '<style>',
        "@font-face { src: local('Consolas'), local('Consolas Bold'); font-family: 'ConsolasFallback'; "
        "font-display: swap; -webkit-size-adjust: 109%; size-adjust: 109%; }",
        "text { font-family: ConsolasFallback, Consolas, 'SFMono-Regular', 'DejaVu Sans Mono', "
        "'Liberation Mono', Menlo, monospace; }",
        f".art {{ fill: {theme['art']}; font-size: {ART_FS}px; }}",
        f".info {{ font-size: {INFO_FS}px; }}",
        f".key {{ fill: {theme['key']}; }} .value {{ fill: {theme['value']}; }} "
        f".cc {{ fill: {theme['cc']}; }} .text {{ fill: {theme['text']}; }} "
        f".add {{ fill: {theme['add']}; }} .del {{ fill: {theme['dele']}; }}",
        '</style>',
        f'<rect width="{width}px" height="{height}px" fill="{theme["bg"]}" rx="15"/>',
        '<g class="art" xml:space="preserve">',
    ]
    for i, line in enumerate(art_lines):
        y = PAD + ART_FS + i * ART_LH
        out.append(f'<text x="{PAD}" y="{y:.1f}" textLength="{len(line) * ART_CW:.1f}" '
                   f'lengthAdjust="spacing" xml:space="preserve">{escape(line)}</text>')
    out.append('</g>')
    out.append('<g class="info" xml:space="preserve">')
    for i, line in enumerate(info_lines):
        if line is None:
            continue
        n, markup = line
        y = PAD + INFO_FS + i * INFO_LH
        out.append(f'<text x="{info_x:.1f}" y="{y:.1f}" textLength="{n * INFO_CW:.1f}" '
                   f'lengthAdjust="spacing" xml:space="preserve">{markup}</text>')
    out.append('</g>')
    out.append('</svg>')
    return "\n".join(out) + "\n"


def main():
    with open(os.path.join(HERE, "ascii_art.txt")) as f:
        art_lines = [l.rstrip("\n") for l in f]
    info_lines = build_info_lines(load_stats())
    for line in info_lines:
        if line and line[0] > INFO_COLS:
            print(f"[warn] a line is {line[0]} characters wide (limit {INFO_COLS}); "
                  "shorten that value in PROFILE or the card will look cramped")
    for name, theme in THEMES.items():
        with open(os.path.join(HERE, name), "w", encoding="utf-8") as f:
            f.write(build_svg(theme, art_lines, info_lines))
        print("wrote", name)


if __name__ == "__main__":
    main()

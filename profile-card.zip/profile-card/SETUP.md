# Setup (5 minutes) - card lives in its own repo

Your profile page only displays the README of the repo named exactly `MuhammadZafran33`
(which you already have). So the card sits in a separate repo, and your profile README
just points at its images.

1. **Create a new PUBLIC repo**, e.g. `profile-card`. (It must be public, or the images
   won't load on your profile.)
2. **Upload everything in this folder** to it, keeping the `.github/workflows/` folder.
3. **Allow the workflow to push.** Repo -> Settings -> Actions -> General -> Workflow
   permissions -> *Read and write permissions* -> Save.
4. **Run it once.** Repo -> Actions -> "Update profile card" -> *Run workflow*.
   This replaces the `--` placeholders with your real repos, stars, followers, commits
   and lines of code. After that it refreshes itself every day.
5. **Show it on your profile.** Open your existing `MuhammadZafran33/MuhammadZafran33`
   README and paste this at the very top (change `profile-card` if you named the repo
   differently, and `main` if its default branch is different):

```html
<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/MuhammadZafran33/profile-card/main/dark_mode.svg">
  <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/MuhammadZafran33/profile-card/main/light_mode.svg">
  <img alt="Muhammad Zafran - GitHub profile card" src="https://raw.githubusercontent.com/MuhammadZafran33/profile-card/main/dark_mode.svg">
</picture>
```

6. *(Optional, more accurate)* Create a personal access token (Settings -> Developer
   settings -> Fine-grained tokens, read access to your repositories) and save it in the
   card repo as a secret named `ACCESS_TOKEN`. Without it, only public repos are counted.

## Customising
- Everything on the card is in the `PROFILE` block at the top of `update_readme.py`.
- Set `birthdate` (format `"YYYY-MM-DD"`) to get an "Uptime" line like the original.
- To change the portrait, edit `ascii_art.txt`, or regenerate it from a photo with
  `pip install opencv-python-headless numpy` then `python make_ascii.py photo.jpg`.
  Then run `python update_readme.py`.
- Keep each line under 60 characters wide. The script warns you if one is too long.
- The image may take a few minutes to refresh on your profile after an update (GitHub caches images).

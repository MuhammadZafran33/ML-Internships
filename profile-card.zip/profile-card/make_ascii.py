import sys
import cv2, numpy as np

SRC = sys.argv[1] if len(sys.argv) > 1 else 'photo.jpg'   # usage: python make_ascii.py my_photo.jpg
img = cv2.imread(SRC)
h, w = img.shape[:2]

# --- seed GrabCut with hand-placed regions (head ellipse + shoulders) ---
mask = np.full((h, w), cv2.GC_BGD, np.uint8)
def fill(shape_fn, val):
    layer = np.zeros((h, w), np.uint8); shape_fn(layer); mask[layer > 0] = val
# probable foreground: generous head + neck + shoulders
fill(lambda l: cv2.ellipse(l, (380, 570), (190, 260), 0, 0, 360, 1, -1), cv2.GC_PR_FGD)
fill(lambda l: cv2.fillPoly(l, [np.array([[270,740],[490,740],[520,800],[740,860],[760,1224],[10,1224],[10,880],[240,800]])], 1), cv2.GC_PR_FGD)
# sure foreground: inner face + torso
fill(lambda l: cv2.ellipse(l, (380, 580), (115, 180), 0, 0, 360, 1, -1), cv2.GC_FGD)
fill(lambda l: cv2.rectangle(l, (60, 960), (700, 1224), 1, -1), cv2.GC_FGD)
bgd = np.zeros((1, 65), np.float64); fgd = np.zeros((1, 65), np.float64)
cv2.grabCut(img, mask, None, bgd, fgd, 10, cv2.GC_INIT_WITH_MASK)
fg = np.where((mask == 1) | (mask == 3), 255, 0).astype(np.uint8)
fg = cv2.morphologyEx(fg, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))

x0, x1, y0, y1 = 140, 620, 325, 950
crop = img[y0:y1, x0:x1]
fgc = fg[y0:y1, x0:x1]
gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
# local contrast so the lit/shadow sides of the face both keep detail
gray = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(4, 4)).apply(gray)

COLS = 64
ch, cw = gray.shape
ROWS = int(COLS * (ch / cw) * 0.5)
g = cv2.resize(gray, (COLS, ROWS), interpolation=cv2.INTER_AREA).astype(float)
m = cv2.resize(fgc, (COLS, ROWS), interpolation=cv2.INTER_AREA)
e = cv2.Canny(cv2.resize(gray, (COLS * 4, ROWS * 4)), 50, 130)
e = cv2.resize(e, (COLS, ROWS), interpolation=cv2.INTER_AREA).astype(float) / 255

ramp = " .'`^\",:;Il!i><~+_-?][}{1)(|/tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@$"
lines = []
for r in range(ROWS):
    row = ''
    for c in range(COLS):
        if m[r, c] < 110:
            row += ' '; continue
        dark = 1 - g[r, c] / 255.0
        dark = min(1, (dark ** 1.25) * 1.05 + e[r, c] * 0.30)
        row += ramp[int(dark * (len(ramp) - 1))]
    lines.append(row.rstrip())
open('ascii_art.txt', 'w').write('\n'.join(lines) + '\n')
print(COLS, ROWS)

